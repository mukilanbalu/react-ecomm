import React, { Component } from 'react';


class Cart extends Component {
    constructor(props){
        super(props);
        this.state ={
           cart: props.product,
           total:0,
           index :0
       }
    this.qtychange=this.qtychange.bind(this);
    }

    componentDidMount(props){

        let total = this.state.cart.reduce((s, f) => {
            return  s +f.cartprice;               // return the sum of the accumulator and the current time, as the the new accumulator
        }, 0);
        this.setState({total: total})
        // console.log(this.state.total);

   

    }

    componentWillReceiveProps(props){
        var sqty = [...props.product]
        let total = sqty.reduce((s, f) => {
            return  s + (f.Quantity*f.Price);               // return the sum of the accumulator and the current time, as the the new accumulator
        }, 0);
                this.setState({
                    cart : props.product,
                    total:total
                    })
    }
  

    qtychange(e,index){
        e.preventDefault();
        var qty= e.target.value;
        var sqty = [...this.state.cart]
        sqty[index].Quantity = qty;
        sqty[index].cartprice= sqty[index].Price * qty;
        let total = sqty.reduce((s, f) => {
            return  s +f.cartprice;               // return the sum of the accumulator and the current time, as the the new accumulator
        }, 0);
        this.setState({ cart : sqty,
                        total: total  
                       });
        console.log('incart',this.state.cart)
        this.forceUpdate();
        this.props.handleQuantity(e.target.value,index);
    }
   

    
    
  
  render() {
    return (
            <div className="col-sm-3  mt-3 ">
              <h4 className="text-left">
               <i class="fas fa-shopping-cart"></i>Cart
               </h4>
                <div className="user-card  p-3">
                    <div className="details" >
                        <table className="table text-left">
                            <tbody>
                        
                                {this.state.cart.map((data,index) =>
                                    <tr >
                                    <td className="pimage"><img src={require('../img/pimg.jpg')}className="img-circle img-fluid mb-3 " alt="user image"/></td>
                                    <td> <h6> {data.Productname}</h6> 
                                    <p className="cart-subs "><span><i className="fa fa-star yellow"/><i className="fa fa-star yellow"/><i className="fa fa-star yellow"/></span> <span>5 | reivews</span> <span>Availablity : <span className="yellow"> In stock</span>  </span> </p>
                                    
                                    <h5 className="d-inline yellow">{data.Price * data.Quantity} </h5>  
                                    <div class="  ml-5 d-inline border-0 open">
                                            <select name="Category"  class="mycategory " value={data.Quantity}  onChange={(e)=>this.qtychange(e,index)} >
                                            <option value="1">1</option>
                                            <option value="3">3</option>
                                            <option value="5">5</option>
                                            </select>
                                    </div> 
                                    </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
                <div className="tax-card my-4 d-flex p-3">
                    <h4 className="text-left">TOTAL</h4>
                    <h2 className="ml-auto yellow">{ this.state.total}</h2>
                </div>
            </div>
      
    );
  }
}
export default Cart;