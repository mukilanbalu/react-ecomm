import React, { Component } from 'react';

class Add extends Component {
    constructor(props){
        super(props);
        // console.log(this.props);
        
        this.state={
            Productname:'',
            Description:'',
            Price:'',
            Quantity:'',
            Category:'',
            image:'',
            pid:'',
                valid:false,
                error:{
                    Productname:false,
                    Description:false,
                    Price:false,
                    Quantity:false,
                    Category:false,
                }
    }
    
    


    this.addProduct=this.addProduct.bind(this);
    // this.saveContact=this.saveContact.bind(this);
    // this.upload=this.upload.bind(this);
    this.handleChange=this.handleChange.bind(this);
}


 handleChange(e) {
        e.preventDefault();
        // console.log(e.target.value)
        this.setState({[e.target.name]: e.target.value});
                
          this.setState({
              error:Object.assign({}, this.state.error, {[e.target.name]: e.target.value === "" ? false :true})
          });
          var err = this.state.error;
         
          var isAllTrue = Object.keys(err).every( function (key) {
            return err[key]===true;
         
        });
        this.setState({valid:true});
        }       
       



addProduct(e){
    e.preventDefault();
    var Product = {
        pid: new Date().valueOf(),
        Productname:this.state.Productname,
        Description:this.state.Description,
        Price:this.state.Price,
        Quantity:this.state.Quantity,
        Category:this.state.Category,

  }
  this.props.addProduct(Product);
  this.setState({Productname:''});
  this.setState({Description:''});
  this.setState({Price:''});
  this.setState({Quantity:''});
  this.setState({Category:''});
  this.setState({ error:{
    Productname:false,
    Description:false,
    Price:false,
    Quantity:false,
    Category:false

  }})
}
// upload(e){
//     let files=e.target.files;
//     let reader = new FileReader();
//     reader.readAsDataURL(files[0]);
//     var error = {...this.state.error}
//     reader.onload=(e)=>{
//         // console.log(e.target.result);
//         this.setState({image: e.target.result})
//         error.image = true;
//           this.setState({error});
//     }
    
// }


  
    render() {
        return ( 
            <div>
 <div className="modal fade" id="myModal">
 <div className="modal-dialog modal-dialog-centered">
 <div className="modal-content">
 
 
     <div className="modal-header">
     <h4 className="modal-title">Add Product</h4>
     <button type="button" className="close" data-dismiss="modal">&times;</button>
     </div>
     
 
     <div className="modal-body">
     <form  className="p-2" >
         <input type="text"   name="Productname" value={this.state.Productname}   onChange={this.handleChange} placeholder="Product name" className="form-control" id="usr"/>
         <p className={(this.state.error.Productname) ? 'd-none' : 'text-danger'}>please enter value</p>


         <input type="email"  name="Description" value={this.state.Description}   onChange={this.handleChange} placeholder="Description" className="form-control" id="email"/>
         <p className={(this.state.error.Description) ? 'd-none' : ' text-danger'}>please enter value</p>

         <input type="number"   name="Price" value={this.state.Price}   onChange={this.handleChange} placeholder="Price" className="form-control" id="numb"/>
         <p className={(this.state.error.Price) ? 'd-none' : 'text-danger'}>please enter value</p>

          <select name="Quantity" class="mycategory form-control" value={this.state.Quantity}   onChange={this.handleChange} >
                                <option selected>Qty</option>
                                <option value="1">1</option>
                                <option value="3">3</option>
                                <option value="5">5</option>
                                </select>
         <p className={(this.state.error.Quantity) ? 'd-none' : ' text-danger'}>please enter value</p>

         

            <select name="Category" class="mycategory form-control"  value={this.state.Category} onChange={this.handleChange} >
            <option selected>select category</option>
            <option value="Headset">Headset</option>
            <option value="Shoe">Shoe</option>
            <option value="Laptop">Laptop</option>
            </select>
         <p className={(this.state.error.Category) ? 'd-none' : ' text-danger'}>please enter value</p>

         
         {/* <input type="file" name="image" className="add-btn" name="fileupload" id="fileupload" onChange={(e)=>this.upload(e)} />
         <p className={(this.state.error.image) ? 'd-none' : ' text-danger'}>please select an image</p>
         */}
         <div className="modal-footer">
         
         <button type="button submit" value="Submit" className={(this.state.valid) ? ' btn btn-secondary ' : ' btn btn-secondary d-none'} 
         onClick={(e)=>{this.addProduct(e)}} >add</button>
        
         <button type="button" className="btn btn-secondary" data-dismiss="modal">Close</button>
     </div>
        
      </form>
     </div>
     

 </div>
 </div>
</div>
</div>

        )
    }
}
export default Add;
        