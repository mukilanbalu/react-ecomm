import React, { Component } from 'react';
import Cart from '../Cart/Cart';
import Add from '../Add/Add';


class Product extends Component {
    
    constructor(props){
        super(props);
        this.state = {
            cart:[ {
                pid:'1',
                Productname:'Soundmagic E10',
                Description:'wires headset',
                Price:1500,
                Quantity:1,
                cartprice: 1500,
                Category:'Headset',
                image:'',
                OFS:false
            },
        ],

            Productname:"",
            Description:"",
            Price:'',
            Quantity:'',
            Category:"",
            image:"",
            clickedpid:'1',
            items:1,
                clicked: false,
                valid:false,
                submit:"",
                index:0,
            products:[
                    {   
                        pid:'1',
                        Productname:'Soundmagic E10',
                        Description:'wires headset',
                        Price:1500,
                        Quantity:1,
                        cartprice:1500,
                        Category:'Headset',
                        image:'',
                        OFS:false
                    }

                ],
                filtered:[
                    {   
                        pid:'1',
                        Productname:'Soundmagic E10',
                        Description:'wires headset',
                        Price:1500,
                        Quantity:1,
                        cartprice:1500,
                        Category:'Headset',
                        image:'',
                        OFS:false
                    }

                ]
        }
        this.addProduct = this.addProduct.bind(this);
        this.costly = this.costly.bind(this);
        this.handleClick=this.handleClick.bind(this);
        this.cheap = this.cheap.bind(this);
        this.search=this.search.bind(this);
        this.filters=this.filters.bind(this);
        this.reset=this.reset.bind(this);
        this.handleQuantity=this.handleQuantity.bind(this);
        
      }
 componentDidMount(){
     this.setState({filtered : this.state.products})
 }
                
            cheap(){
                this.setState(prevState => {
                    this.state.filtered.sort((a, b) => (a.Price - b.Price))
                });
                this.forceUpdate();
            }
            costly(){
                this.setState(prevState => {
                    this.state.filtered.sort((a, b) => (b.Price - a.Price))
                });
            this.forceUpdate()
            }
            search(event){
                // console.log(event.target.value)
                    var updatedList = [...this.state.products];
                    updatedList = updatedList.filter(function(item){
                      return item.Productname.toLowerCase().search(
                        event.target.value.toLowerCase()) !== -1;
                    });
                    // console.log(updatedList)
                    this.setState({filtered: updatedList});
                }
                 
            filters(e){
                e.preventDefault();
                // console.log(this.state.Productname);
                let result = this.state.products.filter(t=>t.Category === e.target.id);
                this.setState({filtered :result });
              
            }
            reset(){
                this.setState({ filtered : this.state.products});
            }
            


      addProduct(obj){
          user = Object.assign({}, this.state.products);    //creating copy of object
          var arr = this.state.products;
          var user = obj;
          arr.push(user);        
          this.setState({
          products: arr
          });
        }
    
        handleChange(e) {
             e.preventDefault();
            this.setState({[e.target.name]: e.target.value});     
        }
        handleQuantity(e,index){
            var cart= [...this.state.cart];
            cart[index].Quantity = e;
            this.setState({cart});
            this.forceUpdate();
            console.log( 'inprod', e)
        }

      handleClick(index,i,){
          this.setState({index});
          var cart= [...this.state.cart];
          var cartitems = this.state.filtered[index];
         
          var pos = this.state.cart.map(function(e) { return e.pid; }).indexOf(i);
          
          if (pos != -1)
          {
           if (this.state.cart[pos].Quantity < 5) {
            cart= [...this.state.cart];
           cart[pos].Quantity = parseInt( cart[pos].Quantity)+ 2;
             this.setState({cart});
             console.log(this.state.cart)
           }
           else {
              cart[pos].OFS=true;
              this.setState({cart,
                filtered:cart});
            //   console.log( cart[pos].OFS)
            console.log(this.state.cart)
           }
          }  
          else{
            cart.push(cartitems);
            this.setState({cart : cart});
        console.log(this.state.cart)
          }
        //   this.setState({clickedpid : i})
          this.setState({items: this.state.cart.length});

        }
        
   

  render() {
  
    return (    
        <div className="col-sm-12 d-flex">
        <div className="row">
        <div className="col-sm-2 ml-3 mt-3 text-left" >
        <h3> categories </h3>
        <ul className="list-unstyled  categories">
            <li onClick={this.reset} > All</li>
            <li id="Headset" onClick={this.filters}  >Headset</li>
            <li id="Shoe" onClick={this.filters} >Shoe </li>
            <li id="Laptop"  onClick={this.filters} >Laptop</li>
        </ul>
        
        </div>
     <div className="User col-sm-6 mt-3  text-center  mx-3 ">
      <div className="add-section mb-3">
         <div className="input-group search  align-baseline">
                <div className="dropdown open mr-auto">
                        <i className="btn btn-sm plain-btn  dropdown-toggle"  id="triggerId" data-toggle="dropdown" aria-haspopup="true"
                                aria-expanded="false"> Sort by</i>
                        <div className="dropdown-menu" aria-labelledby="triggerId">
                            <button className="dropdown-item" onClick={this.cheap}  >Low to high</button>
                            <button className="dropdown-item " onClick={this.costly}  >High to low</button>
                        </div>
                    </div>
                 <input type="text" className="form-control sbar mx-2 " name="Productname" placeholder="search products" onChange={(e)=>this.search(e)} />
                                  <div className="input-group-append ">
                                            <span className="input-group-text search-icon "><i className="fa fa-search" onClick={this.search} ></i></span>
                                        </div>
                                        <div>
                                        <a name="" id="" onClick={this.setsubmit} data-toggle="modal" data-target="#myModal" className="cart-btn py-1 px-3 addbtn" href="#" role="button">Add Product</a>
                                        
                                         <p className="d-inline" > <i class="fas fa-shopping-cart"></i> <span class="badge badge-primary">{this.state.items}</span></p>
                                         </div>   </div>
                </div>

            {/* contact table */}
                <div className="col-sm-12 d-inline ">
                
                    {  this.state.filtered.map((data,index) =>
                    
                          <div className="user-card product-card col-sm-4  m-2  p-3"  >
                            <div class="card-body ">
                            <p  className="text-left"> {data.Category} </p>
                            <h6 class="card-title text-primary  font-weight-bold text-left">{data.Productname}</h6>
                            <img src={require( '../img/pimg.jpg')}className="img-circle img-fluid mb-3" alt="user image"/>
                            <a href="#" className="" onClick={()=>this.handleClick(index,data.pid)}  className={(data.Quantity == 5) ? 'disabled btn btn-primary cart-btn' : ' btn btn-primary cart-btn'}    > {(data.Quantity ==5) ? 'Out of stock' : 'Add to cart'}</a>
                            <div className="price d-flex align-items-baseline mt-3" >
                            <h6 className="text-left yellow font-weight-bold"> {data.Price} </h6> <p className="ml-1" >1000 </p>
                            </div>
                            </div>
                          </div>
                    )}
                </div>
                </div>

                    <Add addProduct={this.addProduct}  />
                <Cart product={this.state.cart} pid={this.state.clickedpid} handleQuantity={this.handleQuantity}  />
                
</div>
             </div>
   
     
    );
  }
}

export default Product;
