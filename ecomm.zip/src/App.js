import React, { Component } from 'react';
import './style.css';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import Prodcut from './Product/Prodcut';

class App extends Component {
  render() {
    return (
      <div className="App">
        <div className="container-fluid">
            <div className="row">
                <div className="col-12 d-flex  mt-5">
                  <Prodcut/>
                </div>
            </div>
        </div>
      </div>
   
     
    );
  }
}

export default App;
